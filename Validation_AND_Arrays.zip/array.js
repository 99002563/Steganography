var Laptop = ["Toshiba","Asus","Apple","HP",,"Acer","Lenovo","Dell","Samsung"];
var Mobile=["iPhone","One-Plus","Pocco","Realme","Motorola","Vivo","Oppo","Samsung","Nokia"];
var TV=["Sony","Toshiba","Onida","Lenovo","Samsung","LG","Philips"];